sudo cp -r usr/* /usr/
sudo cp -r home_pi/* /home/pi/
sudo ldconfig
