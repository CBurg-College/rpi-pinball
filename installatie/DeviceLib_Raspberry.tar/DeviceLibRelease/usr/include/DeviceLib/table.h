// file:   table.h
// Copyright 2022 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.

#ifndef TABLE_H
#define TABLE_H

#ifdef RPI
#include <fstream>
#else
#include <SD.h>
#endif
#include "elements.h"

#define NORECORD -1

typedef struct fieldStruct {
	EString	value;
	uint8_t	length;
	bool	number;
	uint8_t	decimals;
} Field;
typedef EList<Field*> Record;

typedef struct indexStruct {
	EString	value;
	uint8_t	ixrecord;
} IndexEntry;
typedef EList<IndexEntry*> Index;


class Table
{
public:

	Table();
	~Table();

#ifndef RPI
	void setPin( uint8_t cs_pin);
#endif

	bool open( EString fpath);	// returns true if opened
	bool truncate();			// deletes all removed records
	void close();

	void setFields( uint8_t count, ...);					// field count followed by field sizes
	void setIndex( uint8_t ixfield, bool sort = false);
	void setDecimals( uint8_t ixfield, uint8_t decimals);	// number fields are integer values by default

	void updateField( uint8_t ixfield, EString value);
	void updateField( uint8_t ixfield, char* value);
	void updateField( uint8_t ixfield, float value);
	void updateFields( EStrings values);
	void updateFields( EString field, ...);
	void updateFields( char* field, ...);

	EString fieldValue( uint8_t ixfield);

	bool addRecord();			// actually adds the record to the table
	bool updateRecord();
	bool removeRecord();		// removes the current record from the table

	void seekRecord( int32_t ixrecord);	// file seek position = ixrecord * m_szrecord
	void searchRecord( EString indexvalue);	// searches index for indexvalue and reads the corresponding record from the file
	void nextRecord();
	void previousRecord();
	void firstRecord();
	void lastRecord();

	bool isRecord();			// returns true for a valid record index
	bool beginOfTable();
	bool endOfTable();

protected:

	bool writeRecord();
	void readRecord();
	void sortIndex();
	void sort_string();
	void sort_number();

#ifdef RPI
	std::fstream m_file;
#else
	File		m_file;
	uint8_t		m_cs;

#endif
	uint32_t	m_fsize;
	
	Record		m_record;
	uint32_t	m_szrecord;		// total of all field sizes
	int32_t		m_ixrecord;		// current record (file seek position = m_ixrecord * m_szrecord)
	bool		m_delrecord;	// current record is deleted

	Index		m_index;
	int32_t		m_ixindex;		// -1 for eof condition
	int8_t		m_ixfield;		// -1 for not indexed
	bool		m_sorted;

};

#endif
