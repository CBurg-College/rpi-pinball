// file:   grovelcd.h
// Copyright 2022 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef LCD_H
#define LCD_H

#include "actuator.h"
#include "switch.h"
#include "elements.h"

namespace GroveLcd
{

#define NOBLINK			0

// Device I2C Arress
#define LCD_ADDRESS     (0x7c>>1)
#define RGB_ADDRESS     (0xc0>>1)	// dfrobot: (0xc0>>1), grove: (0xc4>>1)

#define REG_RED         0x04        // pwm2
#define REG_GREEN       0x03        // pwm1
#define REG_BLUE        0x02        // pwm0

#define REG_MODE1       0x00
#define REG_MODE2       0x01
#define REG_OUTPUT      0x08

// commands
#define LCD_CLEARDISPLAY 0x01
#define LCD_RETURNHOME 0x02
#define LCD_ENTRYMODESET 0x04
#define LCD_DISPLAYCONTROL 0x08
#define LCD_CURSORSHIFT 0x10
#define LCD_FUNCTIONSET 0x20
#define LCD_SETCGRAMADDR 0x40
#define LCD_SETDDRAMADDR 0x80

// flags for display entry mode
#define LCD_ENTRYRIGHT 0x00
#define LCD_ENTRYLEFT 0x02
#define LCD_ENTRYSHIFTINCREMENT 0x01
#define LCD_ENTRYSHIFTDECREMENT 0x00

// flags for display on/off control
#define LCD_DISPLAYON 0x04
#define LCD_DISPLAYOFF 0x00
#define LCD_CURSORON 0x02
#define LCD_CURSOROFF 0x00
#define LCD_BLINKON 0x01
#define LCD_BLINKOFF 0x00

// flags for display/cursor shift
#define LCD_DISPLAYMOVE 0x08
#define LCD_CURSORMOVE 0x00
#define LCD_MOVERIGHT 0x04
#define LCD_MOVELEFT 0x00

// flags for function set
#define LCD_8BITMODE 0x10
#define LCD_4BITMODE 0x00
#define LCD_2LINE 0x08
#define LCD_1LINE 0x00
#define LCD_5x10DOTS 0x04
#define LCD_5x8DOTS 0x00

#define LINE1	0
#define LINE2	1
#define LINE3	2
#define LINE4	3
#define LINE5	4
#define LINE6	5
#define LINE7	6
#define LINE8	7

#define RED     1
#define GREEN   2
#define YELLOW  3
#define BLUE    4
#define MAGENTA 5
#define CYAN    6
#define WHITE   7

const EString EURO = EString( char( 227));
const EString DEGREE = EString( char( 223));

class LcdUI : public Actuator 
{
public:
	LcdUI();

	void setPin( uint8_t pinUp, uint8_t pinDown, uint8_t pinLeft, uint8_t pinRight, uint8_t pinSet);
	void setConnection( uint8_t connection);
	void setNormalOpen( bool normalopen);
	void setDisplay( uint8_t lines = 2, uint8_t charsize = LCD_5x8DOTS, uint8_t bitmode = LCD_4BITMODE);

	void setPaperColor( uint8_t color);
	void setPaperColor( uint8_t red, uint8_t green, uint8_t blue);
	void setBlink( uint32_t blink_on = NOBLINK, uint32_t blink_off = NOBLINK);

	void clear();
	void on();
	void blink();
	void off();

	void setLabel( uint8_t x, uint8_t line, uint8_t length);
	void setField( uint8_t x, uint8_t line, uint8_t length);

	void setDecimals( uint8_t decimals);
	void setPrefix( EString prefix);
	void setSuffix( EString suffix);

	void setString( EString string);
	void setValue( float value);

	void print( uint8_t x, uint8_t line, EString string);

	void askString( EString label, EString field = "");
	void askValue( EString label);
	void selectString( EString label, EStrings options, uint8_t current = 0);
	void selectString( EString label, uint8_t count, ...);
	void spinValue( EString label, float step = 1, float value = 0, float minValue = 0, float maxValue = 0);
	void showString( EString label, EString field);
	void showValue( EString label, float field);
	void askCode( EString label);
	void message( EString label, EString field);

	bool isSetPressed();

	bool   isOption( EString option);
	EString getString();
	float  getValue();
	EString getCode();

protected:
	void command( uint8_t value);
	void setReg( uint8_t addr, uint8_t dta);
	void display( uint8_t x, uint8_t y, uint8_t l, EString string, bool isfield, bool hascursor);
	void displayLabel( EString label);
	void displayField( EString field);

	Switch		m_up;
	Switch		m_down;
	Switch		m_left;
	Switch		m_right;
	Switch		m_set;

	uint32_t	m_delay;

	uint8_t		m_type;

	uint8_t		m_xlabel;
	uint8_t		m_ylabel;
	uint8_t		m_llabel;
	uint8_t		m_xfield;
	uint8_t		m_yfield;
	uint8_t		m_lfield;

	uint8_t		m_decimals;
	EString		m_prefix;
	EString		m_suffix;
	EString		m_string;
	char		m_char;
	int8_t		m_charix;

	EStrings	m_list;
	int			m_current;

	float		m_value;
	float		m_min;
	float		m_max;
	float		m_step;

	EString		m_code;

	uint8_t		m_lines;
	uint8_t		m_red;
	uint8_t		m_green;
	uint8_t		m_blue;

	uint32_t	m_ton;
	uint32_t	m_toff;
	uint32_t	m_tblink;
	bool		m_isblinking;
	bool		m_blinkon;
};

} // end namespace

#endif // LCD_H
