// file:   users.h
// Copyright 2022 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef USERS_H
#define USERS_H

#include "elements.h"
#include "table.h"


// user levels
extern const EString GUEST;
extern const EString USER;
extern const EString ADMIN;

// user rights
extern const EString ALL;


class Users
{
public:
	~Users();

	bool open( EString fpath, EString initpassword);
	void createUser( EString user, EString level, EString rights, EString info); // rights: comma separated
	void removeUser( EString user);

	void setPassword( EString password);							// set... acts on current user
	void setLevel( EString level);
	void setRights( EString rights);								// rights: comma separated
	void setInfo( EString info);

	bool changeUser( EString user, EString password);				// based on user and password
	bool changeUser( EString password);							// based on password solely (e.g. pincode)

	EString user();
	EString rights();
	EString info();
	bool isLevel( EString level);
	bool hasRights( EString rights); 							// rights: comma separated

	EStrings	listUsers();
	bool		firstUser();
	bool		nextUser();

protected:
	Table	m_table;
	EString	m_initpw;
};

#endif
