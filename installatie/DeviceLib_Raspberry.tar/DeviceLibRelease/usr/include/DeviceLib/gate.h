// file:   gate.h
// Copyright 2020 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef GATE_H
#define GATE_H

#include "sensor.h"

#define GND 0
#define VCC 1

class Gate : public Sensor
{
public:

    Gate();
    ~Gate();

    void setPin( uint8_t pin, uint8_t connection = GND);
	void setConnection( uint8_t connection);
    void triggerEvent( void (*callback)());

    void read();

    bool isClosed();
    bool isOpen();
    bool hasChanged();

private:

    int8_t	m_pin;
    uint8_t m_conn;
    bool	m_closed;
    bool    m_changed;
};

#endif // GATE_H
