// file:   solenoidvalve.h
// Copyright 2022 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef SOLENOIDVALVE_H
#define SOLENOIDVALVE_H

#include "actuator.h"

namespace SolenoidValve
{

class Valve : public Actuator
{
public:
    Valve();
    ~Valve();

    void setPin( uint8_t pin);

    void open( bool setOpen = true);
    void close();

    bool isOpen();

protected:
    int8_t m_pin;
    bool   m_open;
};

} // end namespace

#endif // SOLENOIDVALVE_H
