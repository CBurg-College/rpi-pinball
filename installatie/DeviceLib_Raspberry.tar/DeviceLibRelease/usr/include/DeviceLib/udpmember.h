// file:   udpmember.h
// Copyright 2024 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.
//
//
// SETUP THE MASTER MEMBER
//   UdpMember udp( "master-id", IPv4( "master-ipa"));
//   udp.setMaster();
//   udp.wifi( "ssid", "password");
//   udp.connect( port);
//
// SETUP A GENERAL MEMBER
//   UdpMember udp( "member-id", IPv4( "master-ipa"));
//   udp.wifi( "ssid", "password");
//   udp.connect( port);
//
// Note that on a Raspberry the wifi() call is redundant
// as the wifi setup is handled by the operating system.


#ifndef UDPMEMBER_H
#define UDPMEMBER_H

#include "Arduino.h"
#include "ipv4.h"

extern EString ID_ETSERVER;

class UdpMember
{
public:

	// MEMBER SETUP

	UdpMember();
	UdpMember( EString id, IPv4 masterIpa = IPv4());	
	~UdpMember();							
											
	void setId( EString id);
	void setMasterIpa( IPv4 ipa);

	// NETWORK SETUP

	void wifi( EString ssid, EString password); // will continue to try until wifi completed

	void setMaster( bool ismaster = true); // must be called before connect()
	bool isMaster();

	bool connect( uint16_t port);
	bool isConnected();

	void close();

	EString memberList();

	// EXCHANGE MESSAGES

	void read();
	bool dataReady();
	void message( EString& id, EString& data);
	void send( EString data);
	void broadcast( EString data);

private:

	bool		m_ismaster;

	EString		m_msgid;
	EString		m_msgdata;
	bool		m_msgready;
};

#endif
