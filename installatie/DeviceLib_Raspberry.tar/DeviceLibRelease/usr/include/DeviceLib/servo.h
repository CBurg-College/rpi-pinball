// file:   servo.h
// Copyright 2021 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef SERVO_H
#define SERVO_H

#include "actuator.h"

class Servo : public Actuator
{
public:

    Servo();
    ~Servo();

    void init( uint16_t angleFull = 180, uint16_t usecFreq = 20000, 
               uint16_t usecMin = 500, uint16_t usecMax = 2500, uint16_t msecTime = 750);

    void setPin( uint8_t pin);

    void setForward( bool forward = true);
    void setReverse();

    void angle( uint16_t angle);
    void off();

    bool isOn();

private:

    int8_t   m_pin;
    int16_t  m_angleCur;    // current angle
    long     m_timeCur;     // ending time of current move
    uint16_t m_angleFull;   // full angle for the servo (degr)
    uint16_t m_angleTime;   // time to move through a full angle (msec)
    int16_t  m_freq;
    int16_t  m_min;
    int16_t  m_max;
    bool     m_forward;     // true = forward, false = reverse
};

#endif // UNISTEPPER_H
