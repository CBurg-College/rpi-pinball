// file:   calculator.h
// Copyright 2022 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef CALCULATOR_H
#define CALCULATOR_H

#define PI		3.141592654
#define DEG2RAD	0.01745329252
#define RAD2DEG 57.29577951

#include "elements.h"

class Calculator
{
public:

	Calculator();
	Calculator( const Calculator& value);
	Calculator( float value);
	Calculator( EString value);

	void setDecimals( uint8_t decimals);

	// general calculations

	EString sValue();
	float value();

	Calculator operator=(Calculator value);
	Calculator operator=(float value);
	Calculator operator=(EString value);

	Calculator operator+(Calculator value);
	Calculator operator+(float value);
	Calculator operator+(EString value);
	Calculator operator+=(Calculator value);
	Calculator operator+=(float value);
	Calculator operator+=(EString value);

	Calculator operator-(Calculator value);
	Calculator operator-(float value);
	Calculator operator-(EString value);
	Calculator operator-=(Calculator value);
	Calculator operator-=(float value);
	Calculator operator-=(EString value);

	Calculator operator*(Calculator value);
	Calculator operator*(float value);
	Calculator operator*(EString value);
	Calculator operator*=(Calculator value);
	Calculator operator*=(float value);
	Calculator operator*=(EString value);

	Calculator operator/(Calculator value);
	Calculator operator/(float value);
	Calculator operator/(EString value);
	Calculator operator/=(Calculator value);
	Calculator operator/=(float value);
	Calculator operator/=(EString value);

	bool operator==(Calculator value);
	bool operator==(float value);
	bool operator==(EString value);

	bool operator<(Calculator value);
	bool operator<(float value);
	bool operator<(EString value);
	bool operator<=(Calculator value);
	bool operator<=(float value);
	bool operator<=(EString value);

	bool operator>(Calculator value);
	bool operator>(float value);
	bool operator>(EString value);
	bool operator>=(Calculator value);
	bool operator>=(float value);
	bool operator>=(EString value);

	void power( Calculator value);
	void power( float value);
	void power( EString value);
	void square();
	void cube();
	void squareRoot();
	void cubeRoot();
	void toPercent();
	void toFraction();

	// geometry

	void asLength( float size = 0);
	void asWidth( float size = 0);
	void asHeight( float size = 0);
	void asRadius( float size = 0);

	void circFace();
	void areaFace();
	void circCube();
	void areaCube();
	void volCube();
	void circCircle();
	void areaCircle();
	void areaSphere();
	void volSphere();

	void asAngle( float degr = 0);
	void asOpposite( float size = 0);
	void asAdjacent( float size = 0);
	void asOblique( float size = 0);

	void oppositePyt();
	void oppositeSin();
	void oppositeTan();
	void adjacentPyt();
	void adjacentCos();
	void adjacentTan();
	void obliquePyt();
	void obliqueSin();
	void obliqueCos();
	void angleSin();
	void angleCos();
	void angleTan();
	void inclAngle();

	// economics

	void asDiscount( float percent = 0);
	void asVAT( float percent = 0);
	void asInterest(  float percent = 0);

	void inclDiscount();
	void inclVAT();
	void inclInterest( uint8_t periods);
	void exclDiscount();
	void exclVAT();
	void exclInterest( uint8_t periods);

	// statistics

	void clear();
	void append(); // appends m_value
	void append( EString value);
	void append( float value);

	float total();
	float average();
	float maximum();
	float minimum();

	EString sTotal();
	EString sAverage();
	EString sMaximum();
	EString sMinimum();

protected:

	void init();
	float roundVal( float val);

	uint8_t		m_dec;

	float		m_val;

	float		m_len;
	float		m_wid;
	float		m_hgh;
	float		m_rad;

	float		m_opp;
	float		m_adj;
	float		m_obl;
	float		m_ang;

	float		m_dis;
	float		m_vat;
	float		m_int;

	uint16_t	m_cnt;
	float		m_tot;
	float		m_max;
	float		m_min;
};

#endif // CALCULATOR_H
