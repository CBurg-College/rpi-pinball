// httpserver.h

#ifndef HTTPSERVER_H
#define HTTPSERVER_H

#include "ipv4.h"
#include "elements.h"

#define CONN_CLOSE		0
#define CONN_KEEPALIVE	1

class HttpServer
{
public:

	HttpServer();
	~HttpServer();

	bool begin( uint16_t port);
	IPv4 ipAddress();
	void close();
	void on( EString page, ECallback handler);

	uint8_t args();
	EString argName( uint8_t index);
	EString arg( uint8_t index);
	EString arg( EString name);

	void setResponse( EString response); 			// '200 OK', '204 OK' = stay on page, '404' = unavailable
	void setServer( EString sname);
	void setContentLength( uint16_t length = 0);	// 0 means 'chunked content'
	void setAttachment( EString fname);
	void setImage( EString fname);

	void sendHeader();
	void sendContent( EString content);				// may be called repeatedly
	void sendAttachment();							// sets response and content length automatically
	void sendImage();								// sets response and content length automatically
	void sendClose();

protected:
};

#endif // HTTPSERVER_H
