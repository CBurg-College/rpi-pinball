// file:   tcpserver.h
// Copyright 2020 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.

// NOTE: every sent message starts with a unique 10 character client id
// 		 the client id is stripped automatically before the data is stored

#ifndef TCPSERVER_H
#define TCPSERVER_H

#include "Arduino.h"
#include "ipv4.h"

class TcpService
{
public:

	// DO NOT CALL THESE ROUTINES FROM YOUR PROGRAM
	// THEY ARE MEANT TO INTERACT WITH TcpServer CLASS

	TcpService();
	TcpService( EString id, int client, IPv4 ipa);
	~TcpService();

	void setID( EString id);
	void setClient( int client);
	void setIPAddress( IPv4 ipa);
	EString id();
	int client();
	IPv4 ipaddress();

	void setData( EString data);	// used by the server to dispatch the received data

	// CALL THESE ROUTINES FROM YOUR PROGRAM
	// TYPICALLY 'if ( dataReady() ) str = data();' AND 'send( str);'

	void read();					// dummy, to be consistent with DeviceLib
	bool dataReady();
	EString data();

	void send( EString data);

protected:

	EString		m_id;
	int			m_client;
	IPv4		m_ipa;
	EStrings	m_data;
};

typedef EList<TcpService*>	ServiceList;

class TcpServer
{
public:

	TcpServer( EString id);
	~TcpServer();

	void setID( EString id);

	// network connection
	bool connect( uint16_t port);
	bool isConnected();
	void close();

	// service handling
	TcpService*	service( EString id);
	TcpService* dataService();	// returns the first service that received data
								// handled via the fifo principle (first in, first out)

protected:
};

#endif
