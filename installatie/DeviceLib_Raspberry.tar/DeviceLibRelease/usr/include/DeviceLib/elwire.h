// elwire.h
// Copyright 2022 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef ELWIRE_H
#define ELWIRE_H

#include "actuator.h"

#define NOBLINK 0

class ELWire : public Actuator
{
public:
    ELWire();
    ~ELWire();

    void setPin( uint8_t pin);
    void setBlink( uint32_t blink_on = NOBLINK, uint32_t blink_off = NOBLINK ); // millisec

    void on();
    void off();

	void blink();

private:
    int8_t   m_pin;
    uint32_t m_ton;
    uint32_t m_toff;
	uint32_t m_tblink;
    bool     m_isblinking;
	bool	 m_blinkon;
};

#endif // ELWIRE_H
