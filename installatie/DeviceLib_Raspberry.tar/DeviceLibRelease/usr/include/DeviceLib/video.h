// file:   video.h
// Copyright 2022 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.
//
// Replaces "camera.h" in DeviceLib

#ifndef VIDEO_H
#define VIDEO_H

#ifndef RPI
#error NOTE: You cannot use 'video.h' on Arduino
#else


// link with `pkg-config --cflags --libs opencv`

#include "elements.h"
#include "sensor.h"
#include <opencv2/opencv.hpp>
#include <X11/Xlib.h>


using namespace cv;

#define WEBCAM           0

#define ALT_INTENSITY    0
#define ALT_COLOR        1
#define ALT_REFCOLOR     2
#define ALT_REFINTENSITY 3

struct PNT
{
    uint16_t    x;
    uint16_t    y;
};

struct CLR
{
    uint8_t     b;
    uint8_t     g;
    uint8_t     r;
};

struct SIZ
{
    uint16_t    w;
    uint16_t    h;
};

class Video : public Sensor
{
public:
    Video();
    ~Video();

    void setTitle( EString title);
    void setSize( int width, int height);
    void setFullScreen();
    void setAbortKey( char key);
    void setAcceleration( int accel = 2);

	bool start( EString filename);	    // opens a videofile or camera (filename == WEBCAM)
    void rewind();                      // rewinds a videofile

    void read();                        // shows the next video frame (returns success)
    void stop();					    // stops playing the video and closes the videofile

    bool hasStarted();
    bool didFinish();

    bool play();
	void play( EString filename);	    // plays a video or camera (filename == WEBCAM)
    void show( EString filename);       // shows an image

    Mat  image();
    int  width();
    int  height();

    // Video images can be analised in the following ways:
    // - Color change per block of a sudden size.
    //   * Color deviation of the current image compared to
    //     that of the previous image.
    //     Options are: ALT_INTENSITY and ALT_COLOR.
    //   * Color deviation compared to a reference color.
    //     Options are: ALT_REFERENCE.
    // - Number of colored spots in the image.
    //   * Color deviation compared to a reference color.
    //     Options are: ALT_COUNT.

    // A threshold (a value of 0 to 255) determines
    // the minimal color change to be noticed.
    // Routine 'percentageChanged' returns the percentage of
    // blocks that got a color change.
    // Routine 'spotCount' returns the number of spots of the
    // specified color in a the range of the threshold
    // Pixels, being in the color range but residing in a
    // specified border around the spot, are disregarded.

    void setAnalyze( uint8_t threshold, SIZ blocksize = {0,0} );
    void setReferenceColor( CLR color, bool background);
    int  percentageChanged( int alterationtype);
//    int  spotCount( uint8_t minimalsize = 30);

protected:

    bool scanColor( Mat& img, CLR& clr);
    bool colorChanged( CLR oldclr, CLR newclr);
    bool colorEqual( CLR refclr, CLR newclr);
    int percentageChanged( Mat& imgAB, int alterationtype);
//    bool intensityChanged( QColor oldclr, QColor newclr);
//    bool intensityEqual( QColor refclr, QColor newclr);
//    void gatherSpot( int x, int y);


    char            m_title[64]; // window title when displayed
    VideoCapture*   m_stream;    // video stream
    Mat             m_img;       // video frame
    int             m_width;     // image pixel width
    int             m_height;    // image pixel height
    int             m_accel; // acceleration

    bool            m_busy;
    bool            m_playing;
    bool            m_stop;
    bool            m_stopped;

    int             m_dx;    // block width
    int             m_dy;    // block height
    uint8_t         m_th;    // color treshold

//    EList<PNT> m_spot; // spot point list in m_map
    int             m_minsz; // minimal spot size in pixels
    int             m_cursz; // current spot size in pixels

    EList<CLR>      m_old;   // list of former average block colors
    EList<CLR>      m_new;   // list of new average block colors
    CLR             m_ref;   // reference color
    bool            m_bgc;   // reference color for background
};

#endif // RPI

#endif // VIDEO_H
