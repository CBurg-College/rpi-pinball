// file: waterflow.h
// Copyright 2022 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef WATERFLOW_H
#define WATERFLOW_H

#include "sensor.h"

class WaterFlow : public Sensor
{
public:

    WaterFlow();
    ~WaterFlow();

    void setPin( uint8_t pin);
	void setTicksPerLitre( uint32_t ppl);
	void setInterval( float seconds);

    void read();
	void reset();

	uint32_t ticks();
	float litres();
	float lpm(); // litres per minute

private:

    int8_t		m_pin;
	int8_t		m_ix;
	float		m_interval;
	uint32_t	m_tpl;	// pulses per litre
    uint32_t	m_pulses;
	uint32_t	m_tm;
	float		m_ptot;	// pulses sinces the latest reset
	float		m_pint; // pulses during the latest interval
};

#endif // WATERFLOW_H
