// elements.h
/*
	BASED ON:
	=========
	LinkedList.h - V1.1 - Generic LinkedList implementation
	For instructions, go to https://github.com/ivanseidel/LinkedList
	Created by Ivan Seidel Gomes, March, 2013.
	Released into the public domain.

	ADJUSTMENTS:
	============
	* 'LinkedList' renamed to 'EList'
	* added operator []
	* renamed 'add( ix, item)' to 'insert( ix, item)'
	* renamed 'get' to 'at'
	* renamed 'remove' to 'removeAt'
	* added   'removeAll' calling 'clear'
	* added   'count' calling 'size'
*/

#ifndef __ELEMENTS__
#define __ELEMENTS__

#include <stddef.h>
#include <cstring>
#include <string>
#include <inttypes.h>

///////////
// EList //
///////////

template<class T>
struct ListNode
{
	T data;
	ListNode<T> *next;
};

template <typename T>
class EList{

protected:
	int _size;
	ListNode<T> *root;
	ListNode<T>	*last;

	// Helps "at" method, by saving last position
	ListNode<T> *lastNodeGot;
	int lastIndexGot;
	// isCached should be set to FALSE
	// everytime the list suffer changes
	bool isCached;

	ListNode<T>* getNode(int index);

public:
	EList();
	~EList();

	/*
		Returns current size of EList
	*/
	virtual int size();
	int count() { return size(); }
	/*
		Adds a T object in the specified index;
		Unlink and link the EList correcly;
		Increment _size
	*/
	virtual bool insert(int index, T);
	virtual bool insertAt( int index, T t) { return insert( index, t); }
	/*
		Adds a T object in the end of the EList;
		Increment _size;
	*/
	virtual int add(T);
	virtual int append(T t) { return add(t); }
	/*
		Set the object at index, with T;
		Increment _size;
	*/
	virtual bool unshift(T);
	/*
		Replace object at index;
		If index is not reachable, returns false;
	*/
	virtual bool replace(int index, T);
	virtual bool replaceAt(int index, T t) { return replace( index, t); }
	/*
		Remove object at index;
	*/
	virtual T remove(int index);
	virtual T removeAt(int index) { return remove(index); }
	/*
		Remove last object;
	*/
	virtual T pop();
	/*
		Remove first object;
	*/
	virtual T shift();
	/*
		Get the index'th element on the list;
		Return Element if accessible,
		else, return false;
	*/
	virtual T at(int index);
	virtual T operator[](int index) { return at(index); }

	/*
		Clear the entire array
	*/
	virtual void clear();
	void removeAll() { clear(); }

};

// Initialize EList with false values
template<typename T>
EList<T>::EList()
{
	root=NULL;
	last=NULL;
	_size=0;

	lastNodeGot = root;
	lastIndexGot = 0;
	isCached = false;
}

// Clear Nodes and free Memory
template<typename T>
EList<T>::~EList()
{
	ListNode<T>* tmp;
	while(root!=NULL)
	{
		tmp=root;
		root=root->next;
		delete tmp;
	}
	last = NULL;
	_size=0;
	isCached = false;
}

/*
	Actualy "logic" coding
*/

template<typename T>
ListNode<T>* EList<T>::getNode(int index){

	int _pos = 0;
	ListNode<T>* current = root;

	// Check if the node trying to get is
	// immediatly AFTER the previous got one
	if(isCached && lastIndexGot <= index){
		_pos = lastIndexGot;
		current = lastNodeGot;
	}

	while(_pos < index && current){
		current = current->next;

		_pos++;
	}

	// Check if the object index got is the same as the required
	if(_pos == index){
		isCached = true;
		lastIndexGot = index;
		lastNodeGot = current;

		return current;
	}

	return 0;
}

template<typename T>
int EList<T>::size(){
	return _size;
}

template<typename T>
bool EList<T>::insert(int index, T _t){

	if(index >= _size)
		return add(_t);

	if(index == 0)
		return unshift(_t);

	ListNode<T> *tmp = new ListNode<T>(),
				 *_prev = getNode(index-1);
	tmp->data = _t;
	tmp->next = _prev->next;
	_prev->next = tmp;

	_size++;
	isCached = false;

	return true;
}

template<typename T>
int EList<T>::add(T _t){

	ListNode<T> *tmp = new ListNode<T>();
	tmp->data = _t;
	tmp->next = NULL;

	if(root){
		// Already have elements inserted
		last->next = tmp;
		last = tmp;
	}else{
		// First element being inserted
		root = tmp;
		last = tmp;
	}

	_size++;
	isCached = false;

	return _size - 1;
}

template<typename T>
bool EList<T>::unshift(T _t){

	if(_size == 0)
		return add(_t);

	ListNode<T> *tmp = new ListNode<T>();
	tmp->next = root;
	tmp->data = _t;
	root = tmp;

	_size++;
	isCached = false;

	return true;
}

template<typename T>
bool EList<T>::replace(int index, T _t){
	// Check if index position is in bounds
	if(index < 0 || index >= _size)
		return false;

	ListNode<T> *tmp = getNode(index);
	tmp->data = _t;
	return true;
}

template<typename T>
T EList<T>::pop(){
	if(_size <= 0)
		return T();

	isCached = false;

	if(_size >= 2){
		ListNode<T> *tmp = getNode(_size - 2);
		T ret = tmp->next->data;
		delete(tmp->next);
		tmp->next = NULL;
		last = tmp;
		_size--;
		return ret;
	}else{
		// Only one element left on the list
		T ret = root->data;
		delete(root);
		root = NULL;
		last = NULL;
		_size = 0;
		return ret;
	}
}

template<typename T>
T EList<T>::shift(){
	if(_size <= 0)
		return T();

	if(_size > 1){
		ListNode<T> *_next = root->next;
		T ret = root->data;
		delete(root);
		root = _next;
		_size --;
		isCached = false;

		return ret;
	}else{
		// Only one left, then pop()
		return pop();
	}

}

template<typename T>
T EList<T>::remove(int index){
	if (index < 0 || index >= _size)
	{
		return T();
	}

	if(index == 0)
		return shift();

	if (index == _size-1)
	{
		return pop();
	}

	ListNode<T> *tmp = getNode(index - 1);
	ListNode<T> *toDelete = tmp->next;
	T ret = toDelete->data;
	tmp->next = tmp->next->next;
	delete(toDelete);
	_size--;
	isCached = false;
	return ret;
}

template<typename T>
T EList<T>::at(int index){
	ListNode<T> *tmp = getNode(index);

	return (tmp ? tmp->data : T());
}

template<typename T>
void EList<T>::clear(){
	while(size() > 0)
		shift();
}

/////////////
// EString //
/////////////

enum ENUMSYSTEM { EDEC, EHEX, EOCT, EBIN, EBYTE };

class EString
{
public:

	EString();
	EString( const EString &str);
	EString( const char chr);
	EString( const char* str);
	EString( const std::string &str);
	EString( const int val, const ENUMSYSTEM type = EDEC);
	EString( const int64_t val, const ENUMSYSTEM type = EDEC);
	EString( const uint32_t val, const ENUMSYSTEM type = EDEC);
	EString( const uint64_t val, const ENUMSYSTEM type = EDEC);
	EString( const double f, const int decimals = 2);
	~EString();

    char operator[] ( const uint16_t index);
	EString operator= ( const EString str);
	EString operator+ ( const EString str);
	EString operator+= ( const EString str);
	bool operator== ( const EString str);
	bool operator> ( const EString str);
	bool operator>= ( const EString str);
	bool operator< ( const EString str);
	bool operator<= ( const EString str);
	bool operator!= ( const EString str);

    char charAt( const uint16_t index);
	int compareTo( const EString str);
	EString concat( const EString str1, const EString str2);
	const char* c_str();
	bool endsWith( const EString str);
	bool equals( const EString str);
	bool equalsIgnoreCase( const EString str);
    void getBytes( uint8_t buf[], const uint16_t len);
	int indexOf(  const EString str);
	int indexOf( const char* str);
    int lastIndexOf( const EString str, const uint16_t from = 0);
    int lastIndexOf( const char* str, const uint16_t from = 0);
	int length();
    void remove( const uint16_t index, const uint16_t count = 1);
	EString replace(  const EString str1, const EString str2);
	void reserve( const int size);
    void setCharAt( const uint16_t index, const char chr);
	bool startsWith( const EString str);
    EString substring( const uint16_t from, const uint16_t to = -1);
    void toCharArray( char buf[], const uint16_t len);
    bool isInt();
    bool isFloat();
	int64_t toInt();
	double toFloat();
	void toLowerCase();
	void toUpperCase();
	void trim();

    static EString toHex( const uint8_t *data, const uint16_t size);
    static EString toHexChar( const uint8_t *data, const uint16_t size);
    static EString fillout( const EString str, const char c, const uint16_t size);

protected:

	void setToInt( const int64_t val, const ENUMSYSTEM type);

	std::string S;
};

//////////////
// EStrings //
//////////////

class EStrings : public EList<EString>
{
public:

	void removeFirst( EString str);
	int first( EString str);
	bool has( EString str);
};

///////////////
// ECallback //
///////////////

typedef void(*ECallback)();

#endif // __ELEMENTS__
