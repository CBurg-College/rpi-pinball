// file: thingsboard.h
// Copyright 2021 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef THINGSBOARD_H
#define THINGSBOARD_H

#ifndef RPI
#error NOTE: You cannot use 'thingsboard.h' on Arduino
#else

#include <curl/curl.h>
#include "Arduino.h"

namespace ThingsBoard {

struct MemoryStruct {
    char *memory;
    size_t size;
};

size_t WriteCallback( void *contents, size_t size, size_t nmemb, void *userp);

class IotClient {
public:

    IotClient();
    ~IotClient();

    void connect();

    bool isConnected();

    void addDevice( EString device, EString token);
    EString token( EString device);

    void uploadData( EString device, EString variable, int value);
    void uploadData( EString device, EString variable, double value);
    void uploadData( EString device, EString variable, EString value);
    EString returnData();

    EString error();

protected:

    CURL*               m_curl;
    struct curl_slist*  m_headers;

    EStrings          m_dev;
    EStrings          m_token;
    EString              m_data;
    EString              m_error;
};
   
} // end namespace

#endif //RPI

#endif
