// file:   polarity.h
// Copyright 2022 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.


#ifndef POLARITY_H
#define POLARITY_H

#include "actuator.h"

class Polarity : public Actuator
{
public:
    Polarity();

    void setPin( uint8_t pin1, uint8_t pin2);
    void setPolarity( bool polarity = true);

    void on();
    void swap();
    void off();

protected:
    int8_t m_pin1;
    int8_t m_pin2;
    bool   m_pol;
};

#endif // POLARITY_H
