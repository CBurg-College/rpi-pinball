// ipv4.h

#ifndef IPV4_H
#define IPV4_H

#include "Arduino.h"
#include "elements.h"
#ifndef RPI
#include <ESP8266WiFi.h>
#endif

class IPv4
{
public:

	IPv4();

	IPv4( EString const addr);
	IPv4 operator= ( const EString addr);
	EString	toString();

	#ifdef RPI
	IPv4( uint32_t const addr);
	IPv4 operator= ( const uint32_t addr);
	uint32_t toUint();
	#else
	IPv4( IPAddress const addr);
	IPv4 operator= ( const IPAddress addr);
	IPAddress toIPAddress();	// member ipa
	IPAddress toBCAddress();	// broadcast ipa
	#endif

	IPv4 broadcast();
	bool operator== (const IPv4 addr);
	bool operator!= (const IPv4 addr);

private:

	void setAddr( EString addr);
	#ifdef RPI
	void setAddr( uint32_t addr);
	#else
	void setAddr( IPAddress addr);
	#endif

	uint8_t	m_ba[4];
};

// NETWORK ERROR HANDLING

void setError( EString msg);
EString error();
bool hasError();

// NETWORK MEMBERS

typedef struct {
	EString id;
	IPv4	ipa;
} TMember;

class Members
{
public:

	void set( EString id, IPv4 ipa);
	IPv4 ipa( EString id);
	EString id( IPv4 ipa);
	int count();
	IPv4 ipaAt( int ix);
	EString idAt( int ix);

	void clear();
private:

	EList<TMember*> m_list;
};

// NETWORK MESSAGING

typedef struct {
	EString		id;
	EString		data;
} TMessage;

class Messages
{
public:

	void add( EString id, EString data);
	bool get( EString& id, EString& data); // retrieves in fifo order
	void clear();

private:

	EList<TMessage*>	m_list;
};

#endif // IPV4_H
