// file:   tcpclient.h
// Copyright 2020 D.E.Repolev
//
// This file is part of DeviceLib. DeviceLib is free software and you may distribute it under
// the terms of the GNU General Public License (version 3 or later) as published by the
// Free Software Foundation. The full license text you find at 'https://www.gnu.org/licenses'.
// Disclaimer: DeviceLib is distributed without any warranty.

// NOTE: every sent message is automatically preceeded by the unique 10 character client id

#ifndef RPI
#endif

#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include "Arduino.h"
#include "elements.h"
#include "ipv4.h"

class TcpClient
{
public:

	TcpClient( EString id); // SUPPLY AN ID THAT IS UNIQUE IN THE NETWORK

	EString id();

	bool wifi( EString ssid, EString password);

	bool connect( IPv4 host, uint16_t port, EString id);
	bool isConnected();
	bool close();

	IPv4 ipaddress();
	#ifdef RPI
	IPv4 ipserver();
	#endif

	void read();
	bool dataReady();
	EString data();
	
	bool send( EString data);

protected:

	EString		m_id;
	IPv4		m_ipa;
	EStrings	m_data;
};

#endif
